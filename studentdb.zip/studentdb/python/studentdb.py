import mysql.connector
from mysql.connector import errorcode
#function definition
def select(conn,query):
    cursor = conn.cursor()
    cursor.execute(query)
    results = []
    for row in cursor.fetchall():
        results.append(row)
    cursor.close()
    return results
   
def execute(conn,query):  # update, delete, and insert
    cursor = conn.cursor()
    cursor.execute(query)
    conn.commit()
    
def show(rows):
    for row in rows:
        print(row)
# trying to establish connection to the database
try:
    conn = mysql.connector.connect(
        user="root",
        password="",
        host="localhost",
        database="studentdb")
except mysql.connector.Error as err:
    print("Cannot connect.")
    exit()



# function call
rows = select(conn,"select * from class")
# function call
show(rows)
rows = select(conn,"select * from classstudent")
# function call
show(rows)
rows = select(conn,"select * from professor")
# function call
show(rows)
rows = select(conn,"select * from professorsubject")
# function call
show(rows)
rows = select(conn,"select * from student")
show(rows)
rows = select(conn,"select * from subject")
# function call
show(rows)
