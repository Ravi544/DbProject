-- Created by Vertabelo (http://vertabelo.com)
-- Last modification date: 2021-12-18 10:38:38.176

-- tables
-- Table: Class
CREATE TABLE Class (
    Id int NOT NULL,
    Class_code varchar(20) NOT NULL,
    Begin_Date date NOT NULL,
    End_Date date NOT NULL,
    Subject_Id int NOT NULL,
    Professor_Id int NOT NULL,
    CONSTRAINT Class_pk PRIMARY KEY (Id)
);

-- Table: ClassStudent
CREATE TABLE ClassStudent (
    Id int NOT NULL,
    Student_Id int NOT NULL,
    Class_Id int NOT NULL,
    CONSTRAINT ClassStudent_pk PRIMARY KEY (Id)
);

-- Table: Professor
CREATE TABLE Professor (
    Id int NOT NULL,
    Name varchar(100) NOT NULL,
    Email varchar(100) NOT NULL,
    Phone varchar(20) NOT NULL,
    CONSTRAINT Professor_pk PRIMARY KEY (Id)
);

-- Table: ProfessorSubject
CREATE TABLE ProfessorSubject (
    Id int NOT NULL,
    Professor_Id int NOT NULL,
    Subject_Id int NOT NULL,
    CONSTRAINT ProfessorSubject_pk PRIMARY KEY (Id)
);

-- Table: Student
CREATE TABLE Student (
    Id int NOT NULL,
    Name varchar(30) NOT NULL,
    Email varchar(30) NOT NULL,
    Phone varchar(11) NOT NULL,
    dob date NOT NULL,
    CONSTRAINT Student_pk PRIMARY KEY (Id)
);

-- Table: Subject
CREATE TABLE Subject (
    Id int NOT NULL,
    Name varchar(100) NOT NULL,
    CONSTRAINT Subject_pk PRIMARY KEY (Id)
);

-- foreign keys
-- Reference: ClassStudent_Class (table: ClassStudent)
ALTER TABLE ClassStudent ADD CONSTRAINT ClassStudent_Class FOREIGN KEY ClassStudent_Class (Class_Id)
    REFERENCES Class (Id);

-- Reference: ClassStudent_Student (table: ClassStudent)
ALTER TABLE ClassStudent ADD CONSTRAINT ClassStudent_Student FOREIGN KEY ClassStudent_Student (Student_Id)
    REFERENCES Student (Id);

-- Reference: Class_Professor (table: Class)
ALTER TABLE Class ADD CONSTRAINT Class_Professor FOREIGN KEY Class_Professor (Professor_Id)
    REFERENCES Professor (Id);

-- Reference: Class_Subject (table: Class)
ALTER TABLE Class ADD CONSTRAINT Class_Subject FOREIGN KEY Class_Subject (Subject_Id)
    REFERENCES Subject (Id);

-- Reference: ProfessorSubject_Professor (table: ProfessorSubject)
ALTER TABLE ProfessorSubject ADD CONSTRAINT ProfessorSubject_Professor FOREIGN KEY ProfessorSubject_Professor (Professor_Id)
    REFERENCES Professor (Id);

-- Reference: ProfessorSubject_Subject (table: ProfessorSubject)
ALTER TABLE ProfessorSubject ADD CONSTRAINT ProfessorSubject_Subject FOREIGN KEY ProfessorSubject_Subject (Subject_Id)
    REFERENCES Subject (Id);

-- End of file.

